from distutils.core import setup

setup(name='jubijubi',
      version='1.2',
py_modules = ['main' ],
)
